use rocket::{routes, Build, Rocket};

pub mod default;
pub mod user;

pub fn mount_routers(app: Rocket<Build>) -> Rocket<Build> {
    let new_app = app.mount(
        "/api",
        routes![default::index_page, default::infinite_hello],
    );
    user::mount_router("/api", new_app)
}
