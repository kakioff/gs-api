use rocket::serde::{Deserialize, Serialize};

#[derive(Deserialize, Debug, Serialize)]
#[serde(crate="rocket::serde")]
pub struct User {
    pub name: Option<String>,
    pub passwd: Option<String>,
    pub nick_name: Option<String>
}