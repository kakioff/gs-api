use rocket::{Build, Rocket};

pub mod index;
pub mod models;

pub fn mount_router(base_path: &str, app: Rocket<Build>) -> Rocket<Build> {
    let new_app = index::mount_router(format!("{base_path}/user").as_str(), app);
    new_app
}
