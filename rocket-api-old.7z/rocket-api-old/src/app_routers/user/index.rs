use rocket::{
    post, routes, serde::json::Json, Build, Rocket, log::error_
};
use rocket_db_pools::Connection;

use crate::{
    database::{
        user::{LoginUser, User},
        MySqlDB,
    },
    models::ApiRes,
};
use super::models;

pub fn mount_router(base_url: &str, app: Rocket<Build>) -> Rocket<Build> {
    app.mount(format!("{base_url}/"), routes![create_user, login])
}

#[post("/", data = "<new_user>")]
fn create_user(new_user: Json<models::User>) -> ApiRes<models::User> {
    // let data = format!("{{\"msg\": \"create user: {}\"}}", new_user.name).as_str();
    ApiRes::new().data(new_user.into_inner())
}

#[post("/login", data = "<data>")]
async fn login(data: Json<LoginUser>, mut db: Connection<MySqlDB>) -> ApiRes<String> {
    let data = data.into_inner();
    let user= User::from_login_user(data, &mut db).await;
    if let Err(err) = user {
        return match err {
            sqlx::Error::RowNotFound => {
                ApiRes::new().msg("账号或密码错误！").code(401)
            },
            _ => {
                error_!("Login error: {:?}", err);
                ApiRes::new().msg("位置错误").err()
            },
        };
    }
    let user = user.unwrap();
    ApiRes::new().data("login api".to_owned())
}
