use rocket::get;
use rocket::response::stream::TextStream;
use rocket::tokio::time::{interval, Duration};

use crate::models::SuccJson;

#[get("/")]
pub fn index_page() -> SuccJson {
    return SuccJson("{\"code\": 0}");
}

#[get("/infinite-hellos")]
pub fn infinite_hello() -> TextStream![&'static str] {
    TextStream! {
        let mut interval = interval(Duration::from_secs(1));
        let mut index = 0;
        loop {
            yield "hello";
            index += 1;
            if index >= 10{
                yield "end";
                break;
            }
            interval.tick().await;
        }
    }
}
