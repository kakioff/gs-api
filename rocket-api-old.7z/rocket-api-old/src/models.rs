use rocket::{
    http::{ContentType, Status},
    response,
    serde::{self, Deserialize, Serialize},
    Responder,
};
use std::io::Cursor;

#[derive(Responder, Deserialize)]
#[response(status = 200, content_type = "json")]
#[serde(crate = "rocket::serde")]
pub struct SuccJson(pub &'static str);

#[derive(Debug, Serialize)]
#[serde(crate = "rocket::serde")]
pub struct ApiRes<T: Serialize> {
    pub code: i32,
    pub detail: Option<String>,
    pub count: Option<i64>,
    pub data: Option<T>,
}
impl<'r, 'o: 'r, T: Serialize> response::Responder<'r, 'o> for ApiRes<T> {
    fn respond_to(self, _: &'r rocket::Request<'_>) -> rocket::response::Result<'o> {
        // let res_data = ResData {
        //     data: self.data,
        //     code: self.code.code,
        //     detail: self.detail.clone(),
        // };
        // response::Response::build_from(self.data.respond_to(req).unwrap())
        //     .status(self.code)
        //     .header(ContentType::JSON)
        //     .ok()
        let data = serde::json::to_string(&self).unwrap();
        response::Response::build()
            .status(self.http_status())
            .header(ContentType::JSON)
            .sized_body(data.len(), Cursor::new(data))
            .ok()
    }
}

#[warn(dead_code)]
impl<T: Serialize> ApiRes<T> {
    pub fn new() -> Self {
        Self {
            code: 200,
            detail: None,
            data: None,
            count: None,
        }
    }
    pub fn data(mut self, data: T) -> Self {
        self.data = Some(data);
        self
    }
    pub fn msg<S: Into<String>>(mut self: Self, detail: S) -> Self {
       self.detail = Some(detail.into());
       self
    }
    pub fn code(mut self: Self, code: i32) -> Self {
       self.code = code;
       self
    }
    pub fn ok(mut self: Self) -> Self {
       self.code = 200;
       self
    }
    pub fn err(mut self: Self) -> Self {
       self.code = 500;
       self
    }
    pub fn http_status(&self) -> Status {
        // 转换成 http::Status
        Status::from_code(self.code.try_into().unwrap()).unwrap()
    }
}

