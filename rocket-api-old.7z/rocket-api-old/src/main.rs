use std::env;

use dotenv::dotenv;
use rocket_cors::{AllowedHeaders, AllowedOrigins, Cors, CorsOptions};

mod app_routers;
mod database;
mod middleware;
mod models;

fn cors() -> Cors {
    let allowed_origins = AllowedOrigins::all();
    let allowed_methods = rocket_cors::AllowedMethods::default();

    CorsOptions {
        allowed_origins,
        allowed_methods,
        allowed_headers: AllowedHeaders::all(),
        allow_credentials: true,
        ..Default::default()
    }
    .to_cors()
    .expect("CORS is configured incorrectly")
}

#[rocket::main]
async fn main() -> Result<(), rocket::Error> {
    // region 初始化环境变量、设置数据库的环境变量
    dotenv().unwrap();
    let db_url = env::var("DATABASE_URL").expect("未设置数据库链接");
    let db_url_env = format!("{{goodstuff={{url=\"{}\"}}}}", db_url);
    unsafe {
        env::set_var("ROCKET_DATABASES", &db_url_env);
    }
    assert_eq!(
        env::var("ROCKET_DATABASES").expect("数据库环境变量设置失败"),
        db_url_env
    );
    // endregion

    let mut app = rocket::build().attach(cors()).attach(database::init());
    app = app_routers::mount_routers(app);
    app.launch().await?;
    Ok(())
}
