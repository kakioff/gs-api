use jsonwebtoken::{decode, encode, Algorithm, DecodingKey, EncodingKey, Header, Validation};
use rocket::log::warn_;
use std::env;

use rocket::{
    data,
    serde::{Deserialize, Serialize},
};

#[derive(Debug, Deserialize, Serialize)]
#[serde(crate = "rocket::serde")]
pub struct Claims {
    uid: i32,
    role: String,
    exp: usize,
    iat: usize,
    uname: String,
}

/// 生成token
pub fn generate_token(
    uid: i32,
    role: String,
    uname: String,
) -> Result<String, Box<dyn std::error::Error>> {
    let exp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs() as usize;
    let claims = Claims {
        uid,
        role,
        exp: exp + 60 * 60 * 24 * 30, // 一个月
        iat: exp,
        uname,
    };
    let secret = env::var("ROCKET_SECRET_KEY")?;
    let token = encode(
        &Header::default(),
        &claims,
        &EncodingKey::from_secret(secret.as_bytes()),
    )?;
    Ok(token)
}

///验证token
fn validate_token(token: &str) -> Option<Claims> {
    let secret = env::var("ROCKET_SECRET_KEY").unwrap();
    let validation = Validation::new(Algorithm::HS256);
    let token_data = decode::<Claims>(
        token,
        &DecodingKey::from_secret(secret.as_bytes()),
        &validation,
    );
    match token_data {
        Ok(data) => Some(data.claims),
        Err(err) => {
            warn_!("Incalid token: {err}");
            match err.kind() {
                jsonwebtoken::errors::ErrorKind::ExpiredSignature => {
                    warn_!("token 过期了")
                }
                _ => {}
            }
            None
        }
    }
}

//#[derive(Debug)]
//pub struct ReqUser{
//    pub user: User,
//    pub token: UserToken
//}
