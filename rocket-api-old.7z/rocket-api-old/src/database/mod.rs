use rocket_db_pools::{sqlx, Database, Initializer};

pub mod user;

#[derive(Database)]
#[database("goodstuff")]
pub struct MySqlDB(sqlx::MySqlPool);

pub fn init() -> Initializer<MySqlDB> {
    MySqlDB::init()
}

#[derive(Debug, sqlx::FromRow)]
pub struct DataCount {
    pub count: i64,
}
