use chrono::DateTime;
use rocket::serde::{Deserialize, Serialize};
use rocket_db_pools::Connection;
use sqlx::{Acquire, Decode, Encode, Error, FromRow, MySql};

use super::MySqlDB;

#[derive(Debug, Deserialize)]
#[serde(crate = "rocket::serde")]
pub struct LoginUser {
    pub uname: String,
    pub passwd: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(crate = "rocket::serde")]
pub enum UserRole {
    Dog,
    User,
    Admin,
    Super,
}

impl ToString for UserRole {
    fn to_string(&self) -> String {
        String::from(match self {
            UserRole::Dog => "dog",
            UserRole::User => "user",
            UserRole::Admin => "admin",
            UserRole::Super => "super",
        })
    }
}

impl From<String> for UserRole {
    fn from(value: String) -> Self {
        match value.as_str() {
            "dog" => UserRole::Dog,
            "user" => UserRole::User,
            "admin" => UserRole::Admin,
            "super" => UserRole::Super,
            _ => UserRole::User,
        }
    }
}
impl Encode<'_, MySql> for UserRole {
    fn encode_by_ref(
        &self,
        buf: &mut <MySql as sqlx::database::HasArguments<'_>>::ArgumentBuffer,
    ) -> sqlx::encode::IsNull {
        Encode::<MySql>::encode(self.to_string(), buf)
    }
}
impl Decode<'_, MySql> for UserRole {
    fn decode(
        value: <MySql as sqlx::database::HasValueRef<'_>>::ValueRef,
    ) -> Result<Self, sqlx::error::BoxDynError> {
        let s: String = Decode::<MySql>::decode(value)?;
        match s.to_lowercase().as_str() {
            "dog" => Ok(UserRole::Dog),
            "user" => Ok(UserRole::User),
            "admin" => Ok(UserRole::Admin),
            "super" => Ok(UserRole::Super),
            _ => Err(format!("invalid UserRole: {s}").into()),
        }
    }
}

#[derive(Debug, FromRow, Clone)]
pub struct User {
    pub id: i32,
    pub name: Option<String>,
    pub email: Option<String>,
    pub passwd: Option<String>,
    pub last_login: Option<DateTime<chrono::Utc>>,
    pub last_login_ip: Option<String>,
    pub last_login_ua: Option<String>,
    pub last_signout: Option<DateTime<chrono::Utc>>,
    pub create_ip: Option<String>,
    pub create_ua: Option<String>,
    pub last_update_time: Option<DateTime<chrono::Utc>>,
    pub created: Option<DateTime<chrono::Utc>>,
    pub updated: Option<DateTime<chrono::Utc>>,
    pub deleted: Option<DateTime<chrono::Utc>>,
    pub pushdeer: Option<String>,
    pub role: String,
}

impl User {
    //pub fn new() -> Self {
    //    Self {
    //        id: 0,
    //        role: "user".to_string(),
    //        name: None,
    //        email: None,
    //        passwd: None,
    //        last_login: None,
    //        last_login_ip: None,
    //        last_login_ua: None,
    //        last_signout: None,
    //        create_ip: None,
    //        create_ua: None,
    //        last_update_time: None,
    //        created: None,
    //        updated: None,
    //        deleted: None,
    //        pushdeer: None,
    //    }
    //}
    pub async fn from_login_user(
        login_user: LoginUser,
        db: &mut Connection<MySqlDB>,
    ) -> Result<Self, Error> {
        let inner = db.acquire().await?;
        sqlx::query_as::<_, User>("select * from users where username = ? and password = ?")
            .bind(login_user.uname)
            .bind(login_user.passwd)
            .fetch_one(&mut *inner)
            .await
    }
}
